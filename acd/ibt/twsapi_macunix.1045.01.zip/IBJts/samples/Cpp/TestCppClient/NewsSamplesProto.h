/* Copyright (C) 2026 Interactive Brokers LLC. All rights reserved. This code is subject to the terms
 * and conditions of the IB API Non-Commercial License or the IB API Commercial License, as applicable. */
#pragma once
#ifndef TWS_API_SAMPLES_TESTCPPCLIENT_NEWSSAMPLESPROTO_H
#define TWS_API_SAMPLES_TESTCPPCLIENT_NEWSSAMPLESPROTO_H

#include "HistoricalNewsRequest.pb.h"

class NewsSamplesProto {
public:
#if !defined(USE_WIN_DLL)
    static protobuf::HistoricalNewsRequest HistoricalNewsRequestWithEndTime(int reqId);
    static protobuf::HistoricalNewsRequest HistoricalNewsRequestWithStartTime(int reqId);
#endif
};

#endif
